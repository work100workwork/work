# Mzamomtsha Primary School Website
## Enter to Learn, Leave to Serve

Our mission at Mzamomtsha Primary is to promote a love of learning and of life. While we truly believe that knowledge is power, we - as a school - also recognise that it requires a lot more than knowledge to create a generation that will surpass their predecessors. Because of this, we have chosen to nurture our students in the various ways of life. We hope to instill the core values of this school into our learners. Respect, tolerance, inclusion and excellence are values that we have and will always embody and share through our students and staff.

The vision of our school is simple: it is to create lifelong learners with the skills and mindset to pursue their aspirations and contribute to the world.

***

With that in mind, the Mzamomtsha Primary School has opened this website. Our goal is to allow our students to receive greater opportunities and achieve greater heights by sharing our amazing work with the world. Our 2 main goal of this website are the following:
* Building a teacher body that is capable of sharing their love of life and learning with our learners, which is why we have teacher applications available, and
* Building opportunities and experience through the use of monetary donations that the school will place toward improving facilities and refining the services that we provide so that we can allow our students to see what is out in the world.
